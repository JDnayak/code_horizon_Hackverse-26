from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from datetime import datetime, timezone
import requests
import threading
import time


# ============================================================
# CONFIGURATION
# ============================================================

CROWD_LIMIT = 10

# Replace this with your actual ntfy topic
NTFY_TOPIC = "hackverse26-temple-7x4k91"

NTFY_URL = f"https://ntfy.sh/hackverse26-temple-7x4k91"

# ESP32 is considered offline if no heartbeat is received
# for this many seconds.
ESP32_TIMEOUT = 5.0


# ============================================================
# FASTAPI
# ============================================================

app = FastAPI(
    title="Hackverse Crowd Monitor",
    version="1.0.0"
)


# ============================================================
# STATE
# ============================================================

state_lock = threading.Lock()

current_count = 0

# Human-readable timestamp of the last crowd update
last_update = None

# Monotonic timestamp of the last ESP32 heartbeat
last_heartbeat = 0.0

# Prevent repeated notifications while crowd remains >= limit
alert_sent = False


# ============================================================
# DATA MODELS
# ============================================================

class CrowdUpdate(BaseModel):
    count: int = Field(ge=0)


class Heartbeat(BaseModel):
    device: str = "esp32"


# ============================================================
# NTFY NOTIFICATION
# ============================================================

def send_crowd_alert(count: int):
    """
    Send a push notification through ntfy.
    This function runs in a background thread.
    """

    message = (
        f"Current crowd: {count}\n"
        f"Capacity limit: {CROWD_LIMIT}\n"
        f"Emergency gates are active."
    )

    headers = {
        "Title": "CROWD LIMIT REACHED",
        "Priority": "urgent",
        "Tags": "warning"
    }

    try:
        response = requests.post(
            NTFY_URL,
            data=message.encode("utf-8"),
            headers=headers,
            timeout=5
        )

        response.raise_for_status()

        print(
            f"[NTFY] Alert sent successfully "
            f"(HTTP {response.status_code})"
        )

    except requests.RequestException as error:
        print(f"[NTFY] Alert failed: {error}")


# ============================================================
# ROOT / DASHBOARD
# ============================================================

@app.get("/", response_class=HTMLResponse)
def dashboard():

    return """
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Hackverse Crowd Monitor</title>


<style>

* {
    box-sizing: border-box;
}


body {
    margin: 0;

    font-family:
        Inter,
        system-ui,
        -apple-system,
        BlinkMacSystemFont,
        "Segoe UI",
        sans-serif;

    background: #0b0f14;
    color: #f1f5f9;

    min-height: 100vh;

    padding: 30px;
}


.container {
    max-width: 1100px;
    margin: auto;
}


header {
    margin-bottom: 30px;
}


h1 {
    margin: 0;

    font-size: 32px;
    font-weight: 700;
}


.subtitle {
    margin-top: 8px;

    color: #94a3b8;

    font-size: 15px;
}


/* ============================================================
   MAIN CROWD CARD
   ============================================================ */

.crowd-card {

    background: #111827;

    border: 1px solid #1f2937;

    border-radius: 18px;

    padding: 35px;

    text-align: center;

    margin-bottom: 20px;
}


.crowd-label {

    color: #94a3b8;

    font-size: 14px;

    letter-spacing: 2px;

    margin-bottom: 10px;
}


#crowd {

    font-size: 100px;

    line-height: 1;

    font-weight: 800;

    margin: 10px 0;
}


.people {

    color: #cbd5e1;

    font-size: 18px;
}


#crowdStatus {

    margin-top: 20px;

    display: inline-block;

    padding: 9px 18px;

    border-radius: 999px;

    font-size: 14px;

    font-weight: 700;
}


.normal {

    background: #052e16;

    color: #4ade80;
}


.warning {

    background: #450a0a;

    color: #f87171;
}


/* ============================================================
   GRID
   ============================================================ */

.grid {

    display: grid;

    grid-template-columns:
        repeat(2, minmax(0, 1fr));

    gap: 20px;
}


.card {

    background: #111827;

    border: 1px solid #1f2937;

    border-radius: 16px;

    padding: 25px;
}


.card-title {

    color: #94a3b8;

    font-size: 13px;

    letter-spacing: 1px;

    margin-bottom: 15px;
}


.card-value {

    font-size: 22px;

    font-weight: 700;
}


.status-row {

    display: flex;

    justify-content: space-between;

    align-items: center;

    padding: 10px 0;

    border-bottom: 1px solid #1f2937;
}


.status-row:last-child {

    border-bottom: none;
}


.status-dot {

    display: inline-block;

    width: 9px;

    height: 9px;

    border-radius: 50%;

    margin-right: 8px;
}


.online {

    background: #22c55e;
}


.offline {

    background: #ef4444;
}


.active {

    color: #f87171;
}


.inactive {

    color: #4ade80;
}


/* ============================================================
   FOOTER
   ============================================================ */

.footer {

    margin-top: 25px;

    color: #64748b;

    font-size: 13px;

    text-align: center;
}


/* ============================================================
   MOBILE
   ============================================================ */

@media (max-width: 700px) {

    body {
        padding: 15px;
    }

    .grid {
        grid-template-columns: 1fr;
    }

    #crowd {
        font-size: 75px;
    }

    h1 {
        font-size: 26px;
    }
}

</style>

</head>


<body>


<div class="container">


<header>

<h1>Hackverse Crowd Monitor</h1>

<div class="subtitle">
Real-time crowd monitoring and emergency gate status
</div>

</header>


<!-- ========================================================
     CROWD
     ======================================================== -->

<div class="crowd-card">

<div class="crowd-label">
CURRENT CROWD
</div>

<div id="crowd">
0
</div>

<div class="people">
People Inside
</div>

<div id="crowdStatus" class="normal">
NORMAL
</div>

</div>


<!-- ========================================================
     STATUS CARDS
     ======================================================== -->

<div class="grid">


<!-- SYSTEM STATUS -->

<div class="card">

<div class="card-title">
SYSTEM STATUS
</div>


<div class="status-row">

<span>Backend</span>

<span id="backendStatus">
<span class="status-dot online"></span>
ONLINE
</span>

</div>


<div class="status-row">

<span>ESP32</span>

<span id="esp32Status">
<span class="status-dot offline"></span>
OFFLINE
</span>

</div>


<div class="status-row">

<span>Last Update</span>

<span id="lastUpdate">
--
</span>

</div>

</div>


<!-- GATE STATUS -->

<div class="card">

<div class="card-title">
EMERGENCY GATE
</div>


<div class="status-row">

<span>Status</span>

<span
    id="gateStatus"
    class="inactive"
>
INACTIVE
</span>

</div>


<div class="status-row">

<span>Crowd Limit</span>

<span id="crowdLimit">
10
</span>

</div>

</div>


</div>


<div class="footer">

Hackverse'26 · Crowd Monitoring System

</div>


</div>


<script>


async function updateDashboard() {

    try {

        const response = await fetch(
            "/status",
            {
                cache: "no-store"
            }
        );


        if (!response.ok) {

            throw new Error(
                "HTTP " + response.status
            );

        }


        const data = await response.json();


        /* ====================================================
           CROWD
           ==================================================== */

        document.getElementById(
            "crowd"
        ).textContent = data.count;


        document.getElementById(
            "crowdLimit"
        ).textContent = data.crowd_limit;


        /* ====================================================
           CROWD STATUS
           ==================================================== */

        const crowdStatus =
            document.getElementById(
                "crowdStatus"
            );


        if (data.count >= data.crowd_limit) {

            crowdStatus.textContent =
                "CAPACITY LIMIT REACHED";

            crowdStatus.className =
                "warning";

        }

        else {

            crowdStatus.textContent =
                "NORMAL";

            crowdStatus.className =
                "normal";

        }


        /* ====================================================
           GATE
           ==================================================== */

        const gateStatus =
            document.getElementById(
                "gateStatus"
            );


        if (data.gate_active) {

            gateStatus.textContent =
                "ACTIVE";

            gateStatus.className =
                "active";

        }

        else {

            gateStatus.textContent =
                "INACTIVE";

            gateStatus.className =
                "inactive";

        }


        /* ====================================================
           ESP32
           ==================================================== */

        const esp32Status =
            document.getElementById(
                "esp32Status"
            );


        if (data.esp32_online) {

            esp32Status.innerHTML =
                '<span class="status-dot online"></span>ONLINE';

        }

        else {

            esp32Status.innerHTML =
                '<span class="status-dot offline"></span>OFFLINE';

        }


        /* ====================================================
           LAST UPDATE
           ==================================================== */

        document.getElementById(
            "lastUpdate"
        ).textContent =
            data.last_update || "--";


    }

    catch (error) {

        console.error(
            "Dashboard error:",
            error
        );


        document.getElementById(
            "backendStatus"
        ).innerHTML =
            '<span class="status-dot offline"></span>OFFLINE';

    }

}


/* Update dashboard every 500 ms */

updateDashboard();

setInterval(
    updateDashboard,
    500
);


</script>


</body>

</html>
"""


# ============================================================
# STATUS API
# ============================================================

@app.get("/status")
def status():

    with state_lock:

        count = current_count

        update_time = last_update

        heartbeat_time = last_heartbeat


    # Check whether ESP32 has sent a heartbeat recently
    esp32_online = (
        heartbeat_time > 0
        and
        (time.monotonic() - heartbeat_time)
        <= ESP32_TIMEOUT
    )


    gate_active = (
        count >= CROWD_LIMIT
    )


    return {

        "count": count,

        "gate_active": gate_active,

        "crowd_limit": CROWD_LIMIT,

        "last_update": update_time,

        "esp32_online": esp32_online

    }


# ============================================================
# ESP32 CROWD EVENT
# ============================================================

@app.post("/event")
def receive_event(data: CrowdUpdate):

    global current_count
    global last_update
    global alert_sent


    timestamp = (
        datetime.now(timezone.utc)
        .astimezone()
        .strftime("%Y-%m-%d %H:%M:%S")
    )


    # Update crowd state
    with state_lock:

        current_count = data.count

        last_update = timestamp


    # ========================================================
    # CROWD LIMIT / NOTIFICATION
    # ========================================================

    if current_count >= CROWD_LIMIT:

        # Send notification only once
        # until the crowd drops below the limit.

        with state_lock:

            should_alert = not alert_sent

            if should_alert:
                alert_sent = True


        if should_alert:

            print(
                f"[ALERT] Crowd limit reached: "
                f"{current_count}"
            )


            threading.Thread(

                target=send_crowd_alert,

                args=(current_count,),

                daemon=True

            ).start()


    else:

        # Crowd dropped below limit.
        # Allow a future threshold crossing
        # to generate another notification.

        with state_lock:

            alert_sent = False


    gate_active = (
        current_count >= CROWD_LIMIT
    )


    print(

        f"[ESP32] Crowd = {current_count} | "

        f"Gate = "
        f"{'ACTIVE' if gate_active else 'INACTIVE'}"

    )


    return {

        "accepted": True,

        "count": current_count,

        "gate_active": gate_active

    }


# ============================================================
# ESP32 HEARTBEAT
# ============================================================

@app.post("/heartbeat")
def heartbeat(data: Heartbeat):

    global last_heartbeat


    with state_lock:

        last_heartbeat = time.monotonic()


    return {

        "accepted": True,

        "device": data.device,

        "esp32_online": True

    }


# ============================================================
# HEALTH CHECK
# ============================================================

@app.get("/health")
def health():

    return {

        "status": "ok",

        "service": "Hackverse Crowd Monitor"

    }
