#include<WiFi.h>
#include<HTTPClient.h>

#define IR_PIN1 21
#define IR_PIN2 22
#define IR_PIN3 18
#define IR_PIN4 19

static int counter = 0;
const unsigned long debounceTime = 10;

const char* WIFI_SSID = "LIBRARY_AP1_5G";
const char* WIFI_PASSWORD = "gcek@1234";

const char* SERVER_URL = "http://192.168.0.93:8000/event";

bool ir1 = LOW;
bool ir2 = LOW;
bool ir3 = LOW;
bool ir4 = LOW;

bool lastraw_ir1 = LOW;
bool lastraw_ir2 = LOW;
bool lastraw_ir3 = LOW;
bool lastraw_ir4 = LOW;

unsigned long lastIRchange1 = 0;
unsigned long lastIRchange2 = 0;
unsigned long lastIRchange3 = 0;
unsigned long lastIRchange4 = 0;

void updateSensors(){
  bool raw_ir1 = !(digitalRead(IR_PIN1));
  bool raw_ir2 = !(digitalRead(IR_PIN2));
  bool raw_ir3 = !(digitalRead(IR_PIN3));
  bool raw_ir4 = !(digitalRead(IR_PIN4));

  if(raw_ir1 != lastraw_ir1) {
    lastIRchange1 = millis();
    lastraw_ir1 = raw_ir1;
  }

  if((millis() - lastIRchange1) >= debounceTime) {
    ir1 = raw_ir1;
  }

  if(raw_ir2 != lastraw_ir2) {
    lastIRchange2 = millis();
    lastraw_ir2 = raw_ir2;
  }

  if((millis() - lastIRchange2) >= debounceTime) {
    ir2 = raw_ir2;
  }

  if(raw_ir3 != lastraw_ir3) {
    lastIRchange3 = millis();
    lastraw_ir3 = raw_ir3;
  }

  if((millis() - lastIRchange3) >= debounceTime) {
    ir3 = raw_ir3;
  }

  if(raw_ir4 != lastraw_ir4) {
    lastIRchange4 = millis();
    lastraw_ir4 = raw_ir4;
  }

  if((millis() - lastIRchange4) >= debounceTime) {
    ir4 = raw_ir4;
  }
}


enum State {
  IDLE,
  FIRST_DETECTED,
  SECOND_DETECTED,
};

State stateEntry = IDLE;
State stateExit = IDLE;

void setup() {
    Serial.begin(115200);

    pinMode(IR_PIN1, INPUT);
    pinMode(IR_PIN2, INPUT);
    pinMode(IR_PIN3, INPUT);
    pinMode(IR_PIN4, INPUT);

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    Serial.print("Connecting to WiFi");

    while (WiFi.status() != WL_CONNECTED) {
      delay(500);
      Serial.print(".");
    }

    Serial.println();
    Serial.println("WiFi connected!");

    Serial.print("ESP32 IP: ");
    Serial.println(WiFi.localIP());
}

void loop() {
  updateSensors();
  switch (stateEntry) {

    case IDLE:
      // Person reaches sensor 1 first
      if (ir1 && !ir2) {
        stateEntry = FIRST_DETECTED;
      }
      break;

    case FIRST_DETECTED:
      // Person has now reached sensor 2
      if (ir1 && ir2) {
        stateEntry = SECOND_DETECTED;
      }

      // Person moved away without reaching sensor 2
      if (!ir1 && !ir2) {
        stateEntry = IDLE;
      }
      break;

    case SECOND_DETECTED:
      // Both sensors have been crossed
      if (!ir1 && !ir2) {
        counter++;
        
        stateEntry = IDLE;

        Serial.print("Entry detected! Count = ");
        Serial.println(counter);

        sendCount(counter);
      }
  
    break;
  }

  switch(stateExit) {
    case IDLE:
      // Person reaches sensor 1 first
      if (ir3 && !ir4) {
        stateExit = FIRST_DETECTED;
      }
      break;

    case FIRST_DETECTED:
      // Person has now reached sensor 2
      if (ir3 && ir4) {
        stateExit = SECOND_DETECTED;
      }

      // Person moved away without reaching sensor 2
      if (!ir3 && !ir4) {
        stateExit = IDLE;
      }
      break;

    case SECOND_DETECTED:
      // Both sensors have been crossed
      if (!ir3 && !ir4) {
         if (counter > 0)counter--;
        
        stateExit = IDLE;

        Serial.print("Exit detected! Count = ");
        Serial.println(counter);

        sendCount(counter);
      }
  
    break;
  }
  
}

void sendCount(int count) {

    if (WiFi.status() != WL_CONNECTED) {

        Serial.println("WiFi disconnected!");

        return;
    }


    HTTPClient http;

    http.begin(SERVER_URL);

    http.addHeader(
        "Content-Type",
        "application/json"
    );


    String json = "{";
    json += "\"count\":";
    json += count;
    json += "}";


    Serial.print("Sending: ");
    Serial.println(json);


    int responseCode =
        http.POST(json);


    Serial.print("HTTP response: ");
    Serial.println(responseCode);


    if (responseCode <= 0) {

        Serial.print("HTTP error: ");

        Serial.println(
            http.errorToString(
                responseCode
            ).c_str()
        );

    }

    else {

        Serial.print("Server response: ");

        Serial.println(
            http.getString()
        );

    }


    http.end();
}