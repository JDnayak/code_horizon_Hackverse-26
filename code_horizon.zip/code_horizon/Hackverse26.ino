#include <Servo.h>

#define IR_PIN1 9
#define IR_PIN2 10
#define IR_PIN3 5
#define IR_PIN4 6
#define LED 7
#define BUZZER 8

Servo gate1;
Servo gate2;

static int counter = 0;
static int gate = 1;
static int emergency = 1;
const unsigned long debounceTime = 10;

bool ir1 = LOW;
bool ir2 = LOW;
bool ir3 = LOW;
bool ir4 = LOW;

bool lastraw_ir1 = LOW;
bool lastraw_ir2 = LOW;
bool lastraw_ir3 = LOW;
bool lastraw_ir4 = LOW;

unsigned long lastIRchange1 = 0;
unsigned long lastIRchange2 = 0;
unsigned long lastIRchange3 = 0;
unsigned long lastIRchange4 = 0;

void updateSensors(){
  bool raw_ir1 = !(digitalRead(IR_PIN1));
  bool raw_ir2 = !(digitalRead(IR_PIN2));
  bool raw_ir3 = !(digitalRead(IR_PIN3));
  bool raw_ir4 = !(digitalRead(IR_PIN4));

  if(raw_ir1 != lastraw_ir1) {
    lastIRchange1 = millis();
    lastraw_ir1 = raw_ir1;
  }

  if((millis() - lastIRchange1) >= debounceTime) {
    ir1 = raw_ir1;
  }

  if(raw_ir2 != lastraw_ir2) {
    lastIRchange2 = millis();
    lastraw_ir2 = raw_ir2;
  }

  if((millis() - lastIRchange1) >= debounceTime) {
    ir2 = raw_ir2;
  }

  if(raw_ir3 != lastraw_ir3) {
    lastIRchange3 = millis();
    lastraw_ir3 = raw_ir3;
  }

  if((millis() - lastIRchange3) >= debounceTime) {
    ir3 = raw_ir3;
  }

  if(raw_ir4 != lastraw_ir4) {
    lastIRchange4 = millis();
    lastraw_ir4 = raw_ir4;
  }

  if((millis() - lastIRchange4) >= debounceTime) {
    ir4 = raw_ir4;
  }
}


enum State {
  IDLE,
  FIRST_DETECTED,
  SECOND_DETECTED,
};

State stateEntry = IDLE;
State stateExit = IDLE;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  pinMode(IR_PIN1, INPUT); 
  pinMode(IR_PIN2, INPUT); 
  pinMode(IR_PIN3, INPUT);
  pinMode(IR_PIN4, INPUT);
  pinMode(LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  gate1.attach(2);
  gate1.write(0);
  gate2.attach(3);
  gate2.write(0);
  delay(500);

}

void loop() {
  // put your main code here, to run repeatedly:
  if(counter > 10){
    digitalWrite(LED, HIGH);
    digitalWrite(BUZZER, HIGH);
    delay(50);
    digitalWrite(LED, LOW);
    digitalWrite(BUZZER, LOW);
  }
  if((counter <= 0) && !gate) {
    counter = 0;
    gate = 1;
    gate1.write(0);
    gate2.write(0);
  }
  updateSensors();
  switch (stateEntry) {

    case IDLE:
      // Person reaches sensor 1 first
      if (ir1 && !ir2) {
        stateEntry = FIRST_DETECTED;
      }
      break;

    case FIRST_DETECTED:
      // Person has now reached sensor 2
      if (ir1 && ir2) {
        stateEntry = SECOND_DETECTED;
      }

      // Person moved away without reaching sensor 2
      if (!ir1 && !ir2) {
        stateEntry = IDLE;
      }
      break;

    case SECOND_DETECTED:
      // Both sensors have been crossed
      if (!ir1 && !ir2) {
        counter++;
        
        stateEntry = IDLE;

        Serial.print("Entry detected! Count = ");
        Serial.println(counter);
      }
  
    break;
  }

  switch(stateExit) {
    case IDLE:
      // Person reaches sensor 1 first
      if (ir3 && !ir4) {
        stateExit = FIRST_DETECTED;
      }
      break;

    case FIRST_DETECTED:
      // Person has now reached sensor 2
      if (ir3 && ir4) {
        stateExit = SECOND_DETECTED;
      }

      // Person moved away without reaching sensor 2
      if (!ir3 && !ir4) {
        stateExit = IDLE;
      }
      break;

    case SECOND_DETECTED:
      // Both sensors have been crossed
      if (!ir3 && !ir4) {
         if (counter > 0)counter--;
        
        stateExit = IDLE;

        Serial.print("Exit detected! Count = ");
        Serial.println(counter);
      }
  
    break;
  }
  
  if((counter > 10) && gate){
    gate1.write(90);
    gate2.write(90);
    gate = 0;
  }
  
}
